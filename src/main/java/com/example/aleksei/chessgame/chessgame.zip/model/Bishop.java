package com.example.aleksei.chessgame.model;

import java.util.List;

public class Bishop extends Piece {
    public Bishop(int row, int col, boolean isWhite) {
        super(row, col, isWhite);
    }
    @Override
    public List<Cell> getAvailableMoves(Piece[] pieces) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getSymbol() {
        return "B";
    }

    @Override
    public boolean isMovieValid(int row, int col) {
        // TODO Auto-generated method stub
        return false;
    }
    @Override
    public String getImagePath() {
        if (isWhite()) {
            return "/com/example/aleksei/chessgame/images/w_bishop.png";
        } else {
            return "/com/example/aleksei/chessgame/images/b_bishop.png";
        }
    }
}
