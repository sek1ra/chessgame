package com.example.aleksei.chessgame.model;

import java.util.List;

public class Rook extends Piece {
    public Rook(int x, int y, boolean isWhite) {
        super(x, y, isWhite);
    }

    @Override
    public List<Cell> getAvailableMoves(Piece[] pieces) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getSymbol() {
        return "R";
    }

    @Override
    public boolean isMovieValid(int x, int y) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public String getImagePath() {
        if (isWhite()) {
            return "/com/example/aleksei/chessgame/images/w_rook.png";
        } else {
            return "/com/example/aleksei/chessgame/images/b_rook.png";
        }
    }
}
