package com.example.aleksei.chessgame.model;

import java.util.List;

public abstract class Piece {
    private boolean isWhite;
    private boolean isActive;
    private boolean isCaptured;
    private int row;
    private int col;

    public Piece(int row, int col, boolean isWhite) {
        this.row = row;
        this.col = col;
        this.isWhite = isWhite;
        isActive = false;
        isCaptured = false;
    }
    
    public boolean isWhite() {
        return isWhite;
    }

    public boolean getWhite() {
        return this.isWhite;
    }

    public void setWhite(boolean isWhite) {
        this.isWhite = isWhite;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public void setPosition(int row, int col) {
        this.row = row;
        this.col = col;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public boolean isCaptured() {
        return isCaptured;
    }

    public void setCaptured(boolean isCaptured) {
        this.isCaptured = isCaptured;
    }

    public boolean inPosition(int row, int col) {
        if (row == this.row && col == this.col) {
            return true;
        }
        return false;
    }

    public boolean inPosition(Cell cell) {
        if (row == cell.row() && col == cell.col()) {
            return true;
        }
        return false;
    }


    public abstract List<Cell> getAvailableMoves(Piece[] pieces);
    public abstract boolean isMovieValid(int x, int y);
    public abstract String getSymbol();
    public abstract String getImagePath();
}