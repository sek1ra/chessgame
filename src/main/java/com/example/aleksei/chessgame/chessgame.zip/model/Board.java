package com.example.aleksei.chessgame.model;

public class Board {
    private Piece[] pieces;

    public Board() {
        pieces = new Piece[32];

        //Set pawns
        for (int i = 0; i < 8; i++) {
            pieces[i] = new Pawn(6, i, true);
            pieces[i+16] = new Pawn(1, i, false);
        }
        pieces[8] = new Rook(7, 0, true);
        pieces[9] = new Rook(7, 7, true);
        pieces[24] = new Rook(0, 0, false);
        pieces[25] = new Rook(0, 7, false);

        pieces[10] = new Knight(7, 1, true);
        pieces[11] = new Knight(7, 6, true);
        pieces[26] = new Knight(0, 1, false);
        pieces[27] = new Knight(0, 6, false);

        pieces[12] = new Bishop(7, 2, true);
        pieces[13] = new Bishop(7, 5, true);
        pieces[28] = new Bishop(0, 2, false);
        pieces[29] = new Bishop(0, 5, false);

        pieces[14] = new Queen(7, 3, true);
        pieces[15] = new King(7, 4, true);
        pieces[30] = new Queen(0, 3, false);
        pieces[31] = new King(0, 4, false);
    }

    public Piece[][] setupPieces() {
        Piece[][] buildedBoard = new Piece[8][8];

        //reset board
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                buildedBoard[i][j] = null;
            }
        }

        //set pieces
        for (int i = 0; i < 32; i++) {
            int x;
            int y;
            if (pieces[i] != null && !pieces[i].isCaptured()) {
                x = pieces[i].getRow();
                y = pieces[i].getCol();

                buildedBoard[x][y] = pieces[i];
            }
        }

        return buildedBoard;
    }

    public Piece[] getPieces() {
        return pieces;
    }

    public Piece isPiece(Cell cell) {
        for (int i = 0; i < 32; i++) {
            if (pieces[i].inPosition(cell)) {
                return pieces[i];
            }
        }
        return null;
    }
}