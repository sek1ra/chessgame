package com.example.aleksei.chessgame.model;

import java.util.ArrayList;
import java.util.List;

public class Pawn extends Piece {
    private boolean wasMoved;
    public Pawn(int x, int y, boolean isWhite) {
        super(x, y, isWhite);
        wasMoved = false;
    }

    @Override
    public List<Cell> getAvailableMoves(Piece[] pieces) {
        List<Cell> availMovies = new ArrayList<Cell>();
        if (isWhite()) {
            availMovies.add(new Cell(getRow() - 1, getCol()));
            if (!wasMoved) {
                availMovies.add(new Cell(getRow() - 2, getCol()));
            }
        } else {
            availMovies.add(new Cell(getRow() + 1, getCol()));
            if (!wasMoved) {
                availMovies.add(new Cell(getRow() + 2, getCol()));
            }
        }
        return availMovies;
    }

    @Override
    public boolean isMovieValid(int x, int y) {
        
        return false;
    }

    @Override
    public String getSymbol() {
        return "P";
    }

    @Override
    public String getImagePath() {
        if (isWhite()) {
            return "/com/example/aleksei/chessgame/images/w_pawn.png";
        } else {
            return "/com/example/aleksei/chessgame/images/b_pawn.png";
        }
    }
}
