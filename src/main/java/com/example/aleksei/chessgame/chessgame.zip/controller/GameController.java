package com.example.aleksei.chessgame.controller;

import java.util.List;

import com.example.aleksei.chessgame.model.Board;
import com.example.aleksei.chessgame.model.Cell;
import com.example.aleksei.chessgame.model.Game;
import com.example.aleksei.chessgame.model.Piece;
import com.example.aleksei.chessgame.view.BoardView;

public class GameController {
    private final Board board;
    private final Game game;
    private final BoardView view;

    public GameController(Game game, BoardView view) {
        this.game = game;
        this.board = this.game.getBoard();
        this.view = view;
        this.view.draw(board.setupPieces());
        view.setOnCellClicked(this::handleCellClick);
    }

    public void handleCellClick(Cell clickedCell) {
        Piece piece = board.isPiece(clickedCell);
        if (piece != null) {//clicked on piece
            List<Cell> availMovies = piece.getAvailableMoves(board.getPieces());
            view.highlightMoves(availMovies);
        } else {//clicked on empty field
            view.clearSelection();
        }
    }
}
