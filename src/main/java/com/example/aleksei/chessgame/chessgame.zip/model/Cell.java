package com.example.aleksei.chessgame.model;

public record Cell(int row, int col) {}
