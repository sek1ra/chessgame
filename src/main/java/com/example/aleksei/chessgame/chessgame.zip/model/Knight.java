package com.example.aleksei.chessgame.model;

import java.util.ArrayList;
import java.util.List;

public class Knight extends Piece {
    public Knight(int row, int col, boolean isWhite) {
        super(row, col, isWhite);
    }

    @Override
    public List<Cell> getAvailableMoves(Piece[] pieces) {
        List<Cell> availMovies = new ArrayList<Cell>();
        if (getRow() - 2 >= 0 && getCol() - 1 >= 0 ) {
            availMovies.add(new Cell(getRow() - 2, getCol() - 1));
        }
        if (getRow() - 2 >= 0 && getCol() + 1 < 8 ) {
            availMovies.add(new Cell(getRow() - 2, getCol() + 1));
        }
        if (getRow() + 1 < 8 && getCol() - 2 >= 0 ) {
            availMovies.add(new Cell(getRow() + 1, getCol() - 2));
        }
        if (getRow() - 1 >= 0 && getCol() - 2 >= 0 ) {
            availMovies.add(new Cell(getRow() - 1, getCol() - 2));
        }
        if (getRow() + 2 < 8 && getCol() + 1 < 8 ) {
            availMovies.add(new Cell(getRow() + 2, getCol() + 1));
        }
        if (getRow() + 2 < 8 && getCol() - 1 >= 0 ) {
            availMovies.add(new Cell(getRow() + 2, getCol() - 1));
        }
        if (getRow() - 1 >= 0 && getCol() + 2 < 8 ) {
            availMovies.add(new Cell(getRow() - 1, getCol() + 2));
        }
        if (getRow() + 1 < 8 && getCol() + 2 < 8 ) {
            availMovies.add(new Cell(getRow() + 1, getCol() + 2));
        }

        for (int i = availMovies.size() - 1; i >= 0 ; i--) {
            for (Piece piece : pieces) {
                if (isWhite() == piece.isWhite() && availMovies.get(i).row() == piece.getRow() && availMovies.get(i).col() == piece.getCol() ) {
                    availMovies.remove(i);
                    break;
                }
            }
        }
        return availMovies;
    }

    @Override
    public String getSymbol() {
        return "N";
    }

    @Override
    public boolean isMovieValid(int x, int y) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public String getImagePath() {
        if (isWhite()) {
            return "/com/example/aleksei/chessgame/images/w_knight.png";
        } else {
            return "/com/example/aleksei/chessgame/images/b_knight.png";
        }
    }
}
