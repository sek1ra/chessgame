package com.example.aleksei.chessgame.view;
import java.util.List;
import java.util.function.Consumer;

import com.example.aleksei.chessgame.model.Cell;
import com.example.aleksei.chessgame.model.Piece;
import com.example.aleksei.chessgame.interfaces.IBoardView;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class BoardView implements IBoardView {
    Consumer<Cell> onCellClicked;
    private Button[][] buttons = new Button[8][8];
    GridPane grid = new GridPane();

    public BoardView() {
        grid.setPrefSize(480, 480);
        String cssPath = getClass().getResource("/com/example/aleksei/chessgame/css/styles.css").toExternalForm();
        grid.getStylesheets().add(cssPath);

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                buttons[i][j] = new Button();
                buttons[i][j].setPrefSize(60, 60);
                buttons[i][j].setOnAction(this::handleClick);
                grid.add(buttons[i][j], j, i);
            }
        }
    }

    @Override
    public void handleClick(ActionEvent event) {
        Button clickedButton = (Button) event.getSource();
        int row = GridPane.getRowIndex(clickedButton);
        int col = GridPane.getColumnIndex(clickedButton);
        System.out.println("Clicked cell: [" + row + "," + col + "]");
        handleClick(row, col);
    }

    @Override
    public void draw(Piece[][] pieces) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (pieces[i][j] != null) {
                    Image img = new Image(getClass().getResource(pieces[i][j].getImagePath()).toExternalForm());
                    ImageView view = new ImageView(img);
                    view.setFitWidth(30);
                    view.setFitHeight(30);
                    view.setPreserveRatio(true);
                    buttons[i][j].setGraphic(view);
                }

                if ((i + j) % 2 == 0) {
                    buttons[i][j].getStyleClass().add("cellBlack");
                } else {
                    buttons[i][j].getStyleClass().add("cellWhite");
                }
            }
        }
    }

    @Override
    public void setOnCellClicked(Consumer<Cell> handler) {
        onCellClicked = handler;
    }

    @Override
    public void handleClick(int row, int col) {
        if (onCellClicked != null) {
            onCellClicked.accept(new Cell(row, col));
        }
    }

    @Override
    public GridPane getGridPane() {
        return grid;
    }

    @Override
    public void clearSelection() {
        for (int k = 0; k < 8; k++) {
            for (int l = 0; l < 8; l++) {
                buttons[k][l].getStyleClass().remove("cellActive");
                buttons[k][l].getStyleClass().remove("cellAvailable");
                Node graphic = buttons[k][l].getGraphic();
                if (graphic instanceof Circle) {
                    // Здесь ты можешь, например, удалить кружок:
                    buttons[k][l].setGraphic(null);
                }
            }
        }
    }

    @Override
    public void highlightMoves(List<Cell> availMovies) {
        clearSelection();
        if (availMovies != null && availMovies.size() > 0) {
            for (Cell availMove : availMovies) {
                Circle dot = new Circle(8); // радиус 5
                dot.setFill(Color.BLACK);
                buttons[availMove.row()][availMove.col()].setGraphic(dot);
                buttons[availMove.row()][availMove.col()].getGraphic().setOpacity(0.3);
            }
        }
    }
}
